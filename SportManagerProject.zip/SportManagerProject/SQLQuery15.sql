﻿
update players_sports_rel set PNo = '20200202469' where PNo = '20200202468';
update PlayerInfo set PNo = '20200202470' where PNo = '20200202469';



