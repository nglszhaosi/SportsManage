﻿alter table player_sports_tel 
change column Prize varchar default '无'

ALTER   TABLE   players_sports_rel  ADD   CONSTRAINT   DF_players_sports_rel_FieldName   DEFAULT   '暂无结果，请稍后查看'   FOR   Prize
ALTER   TABLE   players_sports_rel  ADD   CONSTRAINT   DF_players_sports_rel_Rank   DEFAULT   '暂无结果，请稍后查看'   FOR   Rank