﻿insert into test(id,test) values(2,'10''''37');

select PlayerInfo.PNo, PlayerInfo.PName,players_sports_rel.SNo,GamesInfo.GameName,players_sports_rel.Result,players_sports_rel.Rank 	
from players_sports_rel  left join PlayerInfo on players_sports_rel.PNo = PlayerInfo.PNo
left join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo   