﻿select PlayerInfo.PName GameName,GamesInfo.GameAddress,GamesInfo.GameTime 
from players_sports_rel  left join PlayerInfo on players_sports_rel.PNo = PlayerInfo.PNo
left join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo  where players_sports_rel.PNo = '20200202468'


SELECT user.userName,user.userId,mat.matName,mat.matId FROM materil_user mu LEFT JOIN userTable user on 
user.userId=mu.userId LEFT JOIN materialTable mat on mat.matId=mu.matId WHERE mu.userId=1