﻿
ALTER TABLE players_sports_rel ADD constraint players_sports_rel_fk FOREIGN KEY  (SNo) REFERENCES GamesInfo (SNo);
ALTER TABLE players_sports_rel ADD constraint players_sports_rel_fk_1 FOREIGN KEY  (PNo) REFERENCES PlayerInfo (PNo);

select PlayerInfo.PName