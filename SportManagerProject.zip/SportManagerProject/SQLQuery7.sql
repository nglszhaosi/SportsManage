﻿insert into players_sports_rel(PNo,SNo,Result,Rank,Prize) values('" + PNo.Text + "','" + SNoBox.Text + "','" + ResultBox.Text + "','" + RankBox.Text + "';

