﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportManagerProject
{
    public partial class Loader : Form
    {
        public Loader()
        {
            InitializeComponent();
        }

        private void MyProcess_Click(object sender, EventArgs e)
        {



        }

        int startpos = 0;
        Random random = new Random();
       
        private void timer1_Tick(object sender, EventArgs e)
        {
            int n = random.Next(1, 5);
            startpos += n;
            if (startpos > 100) { 
                startpos = 100;
            }
            MyProcess.Value = startpos;
            PercentageLbl.Text = startpos + "%";
            if (MyProcess.Value == 100)
            {
                MyProcess.Value = 0;
                timer1.Stop();
                Login log = new Login();
                log.Show();
                this.Hide();
            }
        }
        private void Loader_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

    }
}
