﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportManagerProject
{
    internal class GlobalData
    {
        public static string UserName;//登录者姓名
        public static string Sex;//登录者性别
        public static string Class;//登录者专业班级
        public static string No;//登录者学号
        public static string Num;//登录者运动会编号
        public static string SNo;//临时保存登录者报名项目编号
        public static string PNo;//临时保存登录者学号

}


}
