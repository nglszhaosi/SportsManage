﻿using SportManagerProject.Operater;
using SportManagerProject.Player;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace SportManagerProject
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (passwordChecked.Checked)
            {
                password.PasswordChar = '\0';   //显示输入
            }
            else
            {
                password.PasswordChar = '*';   //显示*
            }

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\lenove\Documents\SportManagerDB.mdf;Integrated Security=True;Connect Timeout=30");


        /**
         *登录模块
         */
        private void button1_Click(object sender, EventArgs e)
        {
            if (username.Text == "" || password.Text == "")
            {
                
                MessageBox.Show("用户名或密码错误！！！");
                GenerateCode();
                username.Text = "";
                password.Text = "";
                codeBox.Text = "";
            }
            else if (string.IsNullOrEmpty(codeBox.Text) || !codeBox.Text.Equals(code)) {
                MessageBox.Show("验证码输入错误！请重新输入");
                GenerateCode();
                codeBox.Text = "";
            }
            else
            {
                try
                {
                    int roleId = 0;
                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }

                    string sql = "select * from PlayerInfo where Pusername =  '" + username.Text + "' and Ppassword = '" + password.Text + "' ";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        GlobalData.UserName = reader["PName"].ToString();
                        GlobalData.Sex = reader["PSex"].ToString();
                        GlobalData.Class = reader["PClass"].ToString();
                        GlobalData.No = reader["PNo"].ToString();
                        GlobalData.Num = reader["PNum"].ToString();
                        roleId = Convert.ToInt32(reader["role_id"].ToString());
                    }
                    reader.Close();

                    SqlDataAdapter sda = new SqlDataAdapter("select count(*) from PlayerInfo where Pusername =  '" + username.Text + "' and Ppassword = '" + password.Text + "' ", conn);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);

                    if (dt.Rows[0][0].ToString() == "1")
                    {
                        if (roleId == 1)
                        {
                            System.Diagnostics.Debug.WriteLine("(dt.Rows[0][0].ToString()-->" + dt.Rows[0][0].ToString());
                            Playerq playerq = new Playerq();
                            playerq.Show();
                            this.Hide();
                        }
                        else if (roleId == 2)
                        {
                            System.Diagnostics.Debug.WriteLine("(dt.Rows[0][0].ToString()-->" + dt.Rows[0][0].ToString());

                            PlayersManage playersManage = new PlayersManage();
                            playersManage.Show();
                            this.Hide();
                        }
                        conn.Close();
                    }
                    else
                    {
                        MessageBox.Show("用户名或密码错误！请重新输入");
                        GenerateCode();
                        username.Text = "";
                        password.Text = "";
                        codeBox.Text = "";
                    }
                    conn.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        /*
         注册模块
         */
        private void button2_Click(object sender, EventArgs e)
        {
            Register rs = new Register();
            rs.Show();
            this.Hide();             
        }

 

        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;
        private void Login_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }

        private void label9_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }


        private void Login_Load(object sender, EventArgs e)
        {
            //直接调用即可
            GenerateCode();
        }

        string code = "";//保存验证码
        private void GenerateCode(int codeLen = 6)
        {
            code = "";
            //生成随机数字
            Random rand = new Random();
            for (int i = 0; i < codeLen; i++)
            {
                code += rand.Next(0, 9).ToString();
            }

            /*这里将code保存下来做比对验证*/

            //生成验证码图片并显示到pictureBox1
            byte[] bytes = GenerateImg(code);
            MemoryStream ms = new MemoryStream(bytes);
            Image image = System.Drawing.Image.FromStream(ms);
            pictureBox2.Image = image;
        }


        /// <summary>
        /// 生成验证码图片
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        public byte[] GenerateImg(string code)
        {
            Bitmap image = new Bitmap(code.Length * 10, 25);
            Graphics g = Graphics.FromImage(image);
            try
            {
                //清空图片背景色
                g.Clear(Color.White);

                //增加背景干扰线
                Random random = new Random();
                for (int i = 0; i < 30; i++)
                {
                    int x1 = random.Next(image.Width);
                    int x2 = random.Next(image.Width);
                    int y1 = random.Next(image.Height);
                    int y2 = random.Next(image.Height);
                    //颜色可自定义
                    g.DrawLine(new Pen(Color.FromArgb(186, 212, 231)), x1, y1, x2, y2);
                }

                //定义验证码字体
                Font font = new Font("Arial", 10, (FontStyle.Bold | FontStyle.Italic | FontStyle.Strikeout));
                //定义验证码的刷子，这里采用渐变的方式，颜色可自定义
                LinearGradientBrush brush = new LinearGradientBrush(new Rectangle(0, 0, image.Width, image.Height), Color.FromArgb(67, 93, 230), Color.FromArgb(70, 128, 228), 1.5f, true);

                //增加干扰点
                for (int i = 0; i < 100; i++)
                {
                    int x = random.Next(image.Width);
                    int y = random.Next(image.Height);
                    //颜色可自定义
                    image.SetPixel(x, y, Color.FromArgb(random.Next()));
                }

                //将验证码写入图片
                g.DrawString(code, font, brush, 5, 5);


                //图片边框
                g.DrawRectangle(new Pen(Color.FromArgb(93, 142, 228)), 0, 0, image.Width - 1, image.Height - 1);

                //保存图片数据
                MemoryStream stream = new MemoryStream();
                image.Save(stream, ImageFormat.Jpeg);
                return stream.ToArray();
            }
            finally
            {
                g.Dispose();
                image.Dispose();
            }

        }

        //给pictureBox2添加一个点击刷新的功能

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            GenerateCode();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
