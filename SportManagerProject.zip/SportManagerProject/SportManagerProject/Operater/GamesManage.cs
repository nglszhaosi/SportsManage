﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;
using ToolTip = System.Windows.Forms.ToolTip;

namespace SportManagerProject.Operater
{
    public partial class GamesManage : Form
    {
        public GamesManage()
        {
            InitializeComponent();
            populate();
        }

        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\lenove\Documents\SportManagerDB.mdf;Integrated Security=True;Connect Timeout=30");

        /*
        刷新并显示全部信息
         */
        public void populate()
        {
            try
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                string sql = "select * from GamesInfo";
                //string sql = "select PNo,PName,PSex,Pclass,PNum,Pusername,Ppassword from PlayerInfo";
                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(adapter);
                var ds = new DataSet();
                adapter.Fill(ds);
                System.Diagnostics.Debug.WriteLine(sqlCommandBuilder.ToString());
                System.Diagnostics.Debug.WriteLine(adapter.ToString());
                System.Diagnostics.Debug.WriteLine(ds.ToString());
                System.Diagnostics.Debug.WriteLine(ds.Tables[0]);
                
                MGameDGV.DataSource = ds.Tables[0];
               
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        string key = "";//保存选中行项目编号
        private void MGameDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            key = MGameDGV.SelectedRows[0].Cells[0].Value.ToString();//点击获取用户唯一No(学号)  
            System.Diagnostics.Debug.WriteLine("key-->" + key);
        }

        /*
         添加项目
         */
        private void UPSave_Click(object sender, EventArgs e)
        {
            if (SNo.Text == "" || GameName.Text == "" ||  GameTimePicker.Text == "" || GameAddress.Text == "" || MGameSex.SelectedIndex == -1 || MGameAmount.Text =="")

            {
                System.Diagnostics.Debug.WriteLine("GameTimePicker.Text -->" + GameTimePicker.Text);
                MessageBox.Show("项目信息缺失！请检查无误后再添加");
            }
            else
            {
                try
                {
                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }
                    int sexNum = 0;
                    if (MGameSex.SelectedItem.ToString().Trim() == "男") {
                        sexNum = 1;
                    }
                    string sql = "insert into GamesInfo(SNo,GameName,GameTime,GameAddress,amount,Gamesex) values('" + SNo.Text + "','" + GameName.Text + "','" + GameTimePicker.Text + "','" + GameAddress.Text + "','"+ MGameAmount.Text + "',"+sexNum+")";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("项目信息保存成功！");
                    conn.Close();
                    populate();
                    Reset();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        /*
         重置函数
         */
        public void Reset()
        {
            SNo.Text = "";
            GameName.Text = "";
            GameAddress.Text = "";
            GameTimePicker.Text = "";
            MGameAmount.Text = "";
            MGameSex.SelectedIndex = -1;
        }
    
  


        /*
       编辑模块，点击获取待编辑项目信息
       */
        private void MEdit_Click_1(object sender, EventArgs e)
        {
            SNo.Text = MGameDGV.SelectedRows[0].Cells[0].Value.ToString().Trim();
            GameName.Text = MGameDGV.SelectedRows[0].Cells[1].Value.ToString().Trim();
            GameTimePicker.Text = MGameDGV.SelectedRows[0].Cells[2].Value.ToString().Trim();
            GameAddress.Text = MGameDGV.SelectedRows[0].Cells[3].Value.ToString().Trim();
            MGameSex.SelectedItem = MGameDGV.SelectedRows[0].Cells[4].Value.ToString().Trim();
            MGameAmount.Text = MGameDGV.SelectedRows[0].Cells[5].Value.ToString().Trim();
            
        }


          /*
         更新按钮
         */
        private void MUpdate_Click_1(object sender, EventArgs e)
        {
            if (SNo.Text == "" || GameName.Text == "" || GameTimePicker.Text == "" || GameAddress.Text == "" || MGameSex.SelectedIndex == -1 || MGameAmount.Text == "")
            {
                MessageBox.Show("项目信息缺失！请检查无误后更新信息");
            }
            else
            {
                try
                {

                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }

                    int sexNum = 0;
                    if (MGameSex.SelectedItem.ToString().Trim() == "男")
                    {
                        sexNum = 1;
                    }
                    string sql = " update GamesInfo  set  SNo ='" + SNo.Text + "', GameName='" + GameName.Text + "',GameTime='" + GameTimePicker.Text + "',GameAddress='" + GameAddress.Text + "',amount = "+MGameAmount.Text+",Gamesex = "+sexNum+" where SNo = '" + key + "' ";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("项目信息更新成功！");
                    conn.Close();
                    populate();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }


        /*
         删除模块
         */
        private void DeleteBtn_Click_1(object sender, EventArgs e)
        {
            if (key == "")
            {
                MessageBox.Show("请选中一条待删除信息再进行删除！");
            }
            else
            {
                try
                {
                    System.Diagnostics.Debug.WriteLine("key-->" + key);
                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }

                    string sql = "delete from players_sports_rel where SNo = " + key + ";delete from GamesInfo where SNo = " + key + " ";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    System.Diagnostics.Debug.WriteLine("sql-->" + sql);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("项目信息删除成功");
                    conn.Close();
                    populate();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

         /*
        重置按钮
        */
        private void MReset_Click_1(object sender, EventArgs e)
        {
            Reset();
            populate();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /*搜索*/
        private void SearchBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                string sql = "select * from GamesInfo where GameName like  '%"+SearchBox.Text+"%' ";
                //string sql = "select PNo,PName,PSex,Pclass,PNum,Pusername,Ppassword from PlayerInfo";
                System.Diagnostics.Debug.WriteLine("sql-->" + sql);
                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(adapter);
                var ds = new DataSet();
                adapter.Fill(ds);
                MGameDGV.DataSource = ds.Tables[0];
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void MGameDGV_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void GameAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void MGameSex_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {
            GamesManage gamesManage = new GamesManage();
            gamesManage.Show();
            
        }

        private void label8_Click(object sender, EventArgs e)
        {
            PlayersManage playersManage = new PlayersManage();
            playersManage.Show();   
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            InputGrades inputGrades = new InputGrades();
            inputGrades.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            UpdateManagerPwd updatePlayersPwd = new UpdateManagerPwd();
            updatePlayersPwd.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            SentPrize sentPrize = new SentPrize();
            sentPrize.Show();
            this.Hide();
        }

        private void label16_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;
        private void GM_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
    }
}
