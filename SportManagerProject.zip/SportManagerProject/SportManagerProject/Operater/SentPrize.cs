﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace SportManagerProject.Operater
{
    public partial class SentPrize : Form
    {
        public SentPrize()
        {
            InitializeComponent();
            populate();
        }

        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\lenove\Documents\SportManagerDB.mdf;Integrated Security=True;Connect Timeout=30");

        public void populate()
        {
            try
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                //string sql = "select GamesInfo.GameName,GamesInfo.GameAddress,GamesInfo.GameTime from players_sports_rel  left join PlayerInfo on players_sports_rel.PNo =  '" + GlobalData.No + "' left join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo";
                string sql = "select * from (select PlayerInfo.PNo, PlayerInfo.PName,players_sports_rel.SNo,GamesInfo.GameName,players_sports_rel.Rank,players_sports_rel.Prize\r\n   " +
                    "             from players_sports_rel  left join PlayerInfo on players_sports_rel.PNo = PlayerInfo.PNo\r\n             " +
                    "             left join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo )\r\n        " +
                    "            AS Res where Prize != '无奖品'  and Prize != '暂无结果，待发放' ";

                System.Diagnostics.Debug.WriteLine("sql-->" + sql);
                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(adapter);
                var ds = new DataSet();
                adapter.Fill(ds);
                sentPrizeDGV.DataSource = ds.Tables[0];

                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        string PNo = "";
        string SNo = "";
        private void InputGradeDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            nameBox.Text = sentPrizeDGV.SelectedCells[1].Value.ToString().Trim();
            gameName.Text = sentPrizeDGV.SelectedCells[3].Value.ToString().Trim();
             PNo = sentPrizeDGV.SelectedCells[0].Value.ToString().Trim();
             SNo = sentPrizeDGV.SelectedCells[2].Value.ToString().Trim();

        }

        /*
           刷新全部已获奖及待发放奖品信息
         */
        private void button2_Click(object sender, EventArgs e)
        {
            populate();
        }

        /*
         查看奖品待发放名单
         */
        private void MGameAddBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                //string sql = "select GamesInfo.GameName,GamesInfo.GameAddress,GamesInfo.GameTime from players_sports_rel  left join PlayerInfo on players_sports_rel.PNo =  '" + GlobalData.No + "' left join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo";
                string sql = "select * from (select PlayerInfo.PNo, PlayerInfo.PName,players_sports_rel.SNo,GamesInfo.GameName,players_sports_rel.Rank,players_sports_rel.Prize\r\n   " +
                    "             from players_sports_rel  left join PlayerInfo on players_sports_rel.PNo = PlayerInfo.PNo\r\n             " +
                    "             left join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo )\r\n        " +
                    "            AS Res where Prize = '奖品待发放'  ";

                System.Diagnostics.Debug.WriteLine("sql-->" + sql);
                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(adapter);
                var ds = new DataSet();
                adapter.Fill(ds);
                sentPrizeDGV.DataSource = ds.Tables[0];

                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        /*
         查看已发放奖品名单
         */
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                
                //string sql = "select GamesInfo.GameName,GamesInfo.GameAddress,GamesInfo.GameTime from players_sports_rel  left join PlayerInfo on players_sports_rel.PNo =  '" + GlobalData.No + "' left join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo";
                string sql = "select * from (select PlayerInfo.PNo, PlayerInfo.PName,players_sports_rel.SNo,GamesInfo.GameName,players_sports_rel.Rank,players_sports_rel.Prize\r\n   " +
                    "             from players_sports_rel  left join PlayerInfo on players_sports_rel.PNo = PlayerInfo.PNo\r\n             " +
                    "             left join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo )\r\n        " +
                    "            AS Res where Prize  != '奖品待发放' and Prize != '无奖品'  and Prize != '暂无结果，待发放'  ";

                System.Diagnostics.Debug.WriteLine("sql-->" + sql);
                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(adapter);
                var ds = new DataSet();
                adapter.Fill(ds);
                sentPrizeDGV.DataSource = ds.Tables[0];

                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (choosePrize.SelectedIndex==-1 || nameBox == null || gameName == null)
            {
                MessageBox.Show("信息缺失！请检查无误后发放");
            }
            else
            {
                try
                {

                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }

                   
                    // string sql = " update GamesInfo  set  SNo ='" + SNo.Text + "', GameName='" + GameName.Text + "',GameTime='" + GameTime.Text + "',GameAddress='" + GameAddress.Text + "' where SNo = '" + key + "' ";
                    string sql = "update players_sports_rel set Prize = @Prize where PNo = @PNo and SNo = @SNo";


                    SqlCommand updateStyle = new SqlCommand(sql, conn);
                    updateStyle.Parameters.Add(new SqlParameter("@Prize",choosePrize.SelectedItem.ToString().Trim()));
                    updateStyle.Parameters.Add(new SqlParameter("@PNo",PNo));
                    updateStyle.Parameters.Add(new SqlParameter("@SNo", SNo));
                    updateStyle.ExecuteNonQuery();
                    MessageBox.Show("项目信息更新成功！");
                    conn.Close();
                    populate();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            PlayersManage playersManage = new PlayersManage();
            playersManage.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            GamesManage gamesManage = new GamesManage();
            gamesManage.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            InputGrades inputGrades = new InputGrades();
            inputGrades.Show();
            this.Hide();
        }



        private void label7_Click(object sender, EventArgs e)
        {
            UpdateManagerPwd updatePlayersPwd = new UpdateManagerPwd();
            updatePlayersPwd.Show();
            this.Hide();
        }

        private void label16_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;
        private void SP_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
    }
}
