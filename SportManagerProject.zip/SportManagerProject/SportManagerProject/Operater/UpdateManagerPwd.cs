﻿using SportManagerProject.Player;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace SportManagerProject.Operater
{
    public partial class UpdateManagerPwd : Form
    {
        public UpdateManagerPwd()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\lenove\Documents\SportManagerDB.mdf;Integrated Security=True;Connect Timeout=30");

        private void upateBtn_Click(object sender, EventArgs e)
        {
            string pwd = "";
            try
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                string sql2 = "select Ppassword from PlayerInfo where Pusername = 'admin' ";
                SqlCommand cmd2 = new SqlCommand(sql2, conn);
                SqlDataReader reader2 = cmd2.ExecuteReader();

                if (reader2.Read())
                {
                    pwd = reader2["Ppassword"].ToString().Trim();
                }
                reader2.Close();
                conn.Close();

            }
            catch(Exception ex){ 
                MessageBox.Show(ex.Message);
            }
            System.Diagnostics.Debug.WriteLine("newPwdBox-->" + newPwdBox.Text);
            System.Diagnostics.Debug.WriteLine("newPwdTwoBox-->" + newPwdTwoBox.Text);
            if (oldPwdBox.Text == "" || newPwdBox.Text == "" || newPwdTwoBox.Text == "")
            {
                MessageBox.Show("密码修改信息缺失！！！请检查无误后再修改");
            }
            else if (pwd != oldPwdBox.Text.Trim()) {
                MessageBox.Show("旧密码错误！请重新输入");
                oldPwdBox.Text = "";
                newPwdBox.Text = "";
                newPwdTwoBox.Text = "";
            }
            else if (!newPwdBox.Text.Equals(newPwdTwoBox.Text)) {
                MessageBox.Show("两次新密码输入不一致！请检查后重新输入");
                oldPwdBox.Text = "";
                newPwdBox.Text = "";
                newPwdTwoBox.Text = "";
            } else if (oldPwdBox.Text.Equals(newPwdBox.Text)) {
                MessageBox.Show("新旧密码不能相同！请重新输入");
                oldPwdBox.Text = "";
                newPwdBox.Text = "";
                newPwdTwoBox.Text = "";
            }
            else
            {
                try
                {
                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }
                    string sql = "update PlayerInfo set Ppassword = '" + newPwdBox.Text + "' where Pusername = 'admin' ";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("管理员密码修改成功！请重新登录");
                    conn.Close();
                    Login login = new Login();
                    login.Show();
                    this.Hide();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            PlayersManage playersManage = new PlayersManage();
            playersManage.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            GamesManage gamesManage = new GamesManage();
            gamesManage.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            InputGrades inputGrades = new InputGrades();
            inputGrades.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            SentPrize sentPrize = new SentPrize();
            sentPrize.Show();
            this.Hide();
        }

        private void label16_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;
        private void UPP_MOuseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                oldPwdBox.PasswordChar = '\0';   //显示输入
                newPwdBox.PasswordChar = '\0';   //显示输入
                newPwdTwoBox.PasswordChar = '\0';   //显示输入
            }
            else
            {
                oldPwdBox.PasswordChar = '*';   //显示*
                newPwdBox.PasswordChar = '*';   //显示*
                newPwdTwoBox.PasswordChar = '*';   //显示*
            }
        }
    }
}
