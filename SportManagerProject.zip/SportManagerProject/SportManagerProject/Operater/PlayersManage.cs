﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;
using System.Runtime.InteropServices;

namespace SportManagerProject.Operater
{
    public partial class PlayersManage : Form
    {
        public PlayersManage()
        {
            InitializeComponent();
            populate();
        }

        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\lenove\Documents\SportManagerDB.mdf;Integrated Security=True;Connect Timeout=30");

        /*
         信息添加模块
         */
        private void UPSave_Click(object sender, EventArgs e)
        {
            if (MNo.Text == "" || MName.Text == "" || MSex.SelectedIndex == -1 || MClass.Text == "" || MNum.Text == "" || MUsername.Text == "" || MPassword.Text == "")
            {
                MessageBox.Show("信息缺失！请检查无误后保存");
            }
            else
            {
                try
                {

                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }
                    string sql = "insert into PlayerInfo(PNo,PName,PSex,Pclass,PNum,Pusername,Ppassword,role_id) values('" + MNo.Text + "','" + MName.Text + "','" + MSex.SelectedItem.ToString().Trim() + "','" + MClass.Text + "','" + MNum.Text + "','" + MUsername.Text + "','" + MPassword.Text + "',1)";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("信息保存成功！");
                    conn.Close();
                    populate();
                    Reset();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        /*
         信息刷新显示模块
         */
        public void populate()
        {
            try
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                //string sql = "select * from PlayerGrades";
                string sql = "select PNo,PName,PSex,Pclass,PNum,Pusername,Ppassword from PlayerInfo where role_id = 1";
                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(adapter);
                var ds = new DataSet();
                adapter.Fill(ds);
                MInfoDGV.DataSource = ds.Tables[0];
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /*
         重置按钮
         */
        public void Reset() {
            MNo.Text = "";
            MName.Text = "";
            MSex.SelectedIndex = -1;
            MClass.Text = "";
            MNum.Text = "";
            MUsername.Text = "";
            MPassword.Text = "";
        }

        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        String key = "";//选中后，保存待用户唯一PNo
        /*
         获取待删除用户唯一No
         */
        private void GradesDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            key = MInfoDGV.SelectedRows[0].Cells[0].Value.ToString();//点击获取用户唯一No(学号)  
        }
        /*
           用户删除模块
         */
        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (key == "")
            {
                MessageBox.Show("请选中一条待删除信息再进行删除！");
            }
            else
            {
                try
                {
                    System.Diagnostics.Debug.WriteLine("key-->" + key);
                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }
                    string sql = "delete from players_sports_rel where PNo = '" + key + "';delete from PlayerInfo where PNo = '" + key + "'";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    System.Diagnostics.Debug.WriteLine("sql-->" + sql);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("用户信息删除成功");
                    conn.Close();
                    populate();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        /*
         * 用户编辑模块，将待修改的用户信息传入修改框
        */
        private void Update_Click(object sender, EventArgs e)
        {
            MNo.Text = MInfoDGV.SelectedRows[0].Cells[0].Value.ToString().Trim();
            MName.Text = MInfoDGV.SelectedRows[0].Cells[1].Value.ToString().Trim();
            MSex.SelectedItem = MInfoDGV.SelectedRows[0].Cells[2].Value.ToString().Trim();
            MClass.Text = MInfoDGV.SelectedRows[0].Cells[3].Value.ToString().Trim();
            MNum.Text = MInfoDGV.SelectedRows[0].Cells[4].Value.ToString().Trim();
            MUsername.Text = MInfoDGV.SelectedRows[0].Cells[5].Value.ToString().Trim();
            MPassword.Text = MInfoDGV.SelectedRows[0].Cells[6].Value.ToString().Trim();
        }

        /*
         更新按钮模块
         */
        private void button1_Click(object sender, EventArgs e)
        {
            if (MNo.Text == "" || MName.Text == "" || MSex.SelectedIndex == -1 || MClass.Text == "" || MNum.Text == "" || MUsername.Text == "" || MPassword.Text == "")
            {
                MessageBox.Show("信息缺失！请检查无误后更新信息");
            }
            else
            {
                try
                {

                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }
                    string sql = " update PlayerInfo  set  PNo ='" + MNo.Text + "', PName='" + MName.Text + "',PSex='" + MSex.SelectedItem.ToString() + "',Pclass='" + MClass.Text + "',PNum='" + MNum.Text + "', Pusername='" + MUsername.Text + "',Ppassword='" + MPassword.Text + "' where PNo = '"+key+"' ";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("信息更新成功！");
                    conn.Close();
                    populate();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }


        private void MReset_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void MSex_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void MInfoDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {
            GamesManage gamesManage = new GamesManage();
            gamesManage.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            InputGrades  inputGrades = new InputGrades();
            inputGrades.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            UpdateManagerPwd updatePlayersPwd = new UpdateManagerPwd();
            updatePlayersPwd.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            SentPrize sentPrize = new SentPrize();
            sentPrize.Show();
            this.Hide();
        }

        private void label16_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;
        private void PM_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
    } 
}
