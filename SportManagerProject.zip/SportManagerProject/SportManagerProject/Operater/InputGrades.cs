﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace SportManagerProject.Operater
{
    public partial class InputGrades : Form
    {
        public InputGrades()
        {
            InitializeComponent();
            populate();
        }


        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\lenove\Documents\SportManagerDB.mdf;Integrated Security=True;Connect Timeout=30");

        /*
         刷新信息模块
         */
        public void populate()
        {
            try
            {
                if(conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                
                //string sql = "select GamesInfo.GameName,GamesInfo.GameAddress,GamesInfo.GameTime from players_sports_rel  left join PlayerInfo on players_sports_rel.PNo =  '" + GlobalData.No + "' left join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo";
                string sql = "select PlayerInfo.PNo, PlayerInfo.PName,players_sports_rel.SNo,GamesInfo.GameName,players_sports_rel.Result,players_sports_rel.Rank" +
                    " \tfrom players_sports_rel  left join PlayerInfo on players_sports_rel.PNo = PlayerInfo.PNo" +
                    "\tleft join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo   ";
                System.Diagnostics.Debug.WriteLine("sql-->" + sql);
                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(adapter);
                var ds = new DataSet();
                adapter.Fill(ds);
                InputGradeDGV.DataSource = ds.Tables[0];
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }


        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /*成绩添加*/
        private void MGameAddBtn_Click(object sender, EventArgs e)
        {
            if (PNo.Text == "" || SName.Text == "" || SNoBox.Text == "" || GameName.Text == "" || ResultBox.Text == "" || RankBox.Text == "")
            {
                MessageBox.Show("信息缺失！请检查无误后再添加");
            }
            else
            {
                try
                {
                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }

                    string prizeState = "无奖品";
                    if (Convert.ToInt32(RankBox.Text.Trim()) <= 3) {
                        prizeState = "奖品待发放";
                    }
                  
                    //string sql = "insert into players_sports_rel(PNo,SNo,Result,Rank,Prize) values('" + PNo.Text + "','" + SNoBox.Text + "','" + ResultBox.Text + "','" + RankBox.Text + "','"+prizeState+"');" ;
                    string sql = "update  players_sports_rel set PNo = @PNo,SNo = @SNoBox ,Result = @ResultBox,Rank =@Rank,Prize= @prizeState  " +
                         "from (select players_sports_rel.PNo, PlayerInfo.PName,players_sports_rel.SNo,GamesInfo.GameName,\r\n               " +
                         "players_sports_rel.Result,players_sports_rel.Rank from players_sports_rel\r\n             " +
                         " left join PlayerInfo on players_sports_rel.PNo = PlayerInfo.PNo\r\n         " +
                         " left join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo ) AS u " +
                         "where players_sports_rel.PNo = @PlayerNo and players_sports_rel.SNo = @GameNo  ";

                    
                    SqlCommand updateStyle = new SqlCommand(sql, conn);
                    updateStyle.Parameters.Add(new SqlParameter("@PNo", PNo.Text));
                    updateStyle.Parameters.Add(new SqlParameter("@SNoBox", SNoBox.Text));
                    updateStyle.Parameters.Add(new SqlParameter("@ResultBox", ResultBox.Text));
                    updateStyle.Parameters.Add(new SqlParameter("@Rank", RankBox.Text));
                    updateStyle.Parameters.Add(new SqlParameter("@prizeState", prizeState));
                    updateStyle.Parameters.Add(new SqlParameter("@PlayerNo", PlayerNo));
                    updateStyle.Parameters.Add(new SqlParameter("@GameNo", GameNo));

                    System.Diagnostics.Debug.WriteLine("sql-->"+sql);
            
                    updateStyle.ExecuteNonQuery();


                    MessageBox.Show("成绩录入成功！");
                    conn.Close();
                    Reset();
                    populate();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        /*
         重置函数
         */
        public void Reset() {
            PNo.Text = "";
            SName.Text = "";
            SNoBox.Text = "";
            GameName.Text = "";
            ResultBox.Text = "";
            RankBox.Text = "";
        }

        private void MReset_Click(object sender, EventArgs e)
        {
            Reset();
        }

        /*搜索模块*/
        private void SearchBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                //string sql = "select * from players_sports_rel where PNo = '" + SearchBox.Text + "' ";
                //string sql = "select PNo,PName,PSex,Pclass,PNum,Pusername,Ppassword from PlayerInfo";
                string sql = "select * from (select PlayerInfo.PNo, PlayerInfo.PName,players_sports_rel.SNo,GamesInfo.GameName," +
                    "\r\nplayers_sports_rel.Result,players_sports_rel.Rank \r\nfrom players_sports_rel  " +
                    "\r\nleft join PlayerInfo on players_sports_rel.PNo = PlayerInfo.PNo" +
                    "\r\nleft join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo )" +
                    "\r\nas S where PNo = '"+SearchBox.Text+"'  ";

                System.Diagnostics.Debug.WriteLine("sql-->" + sql);
                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(adapter);
                var ds = new DataSet();
                adapter.Fill(ds);
                InputGradeDGV.DataSource = ds.Tables[0];
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        string PlayerNo = "";//保存待修改学号
        String GameNo = "";//保存待修改项目编号

        /*编辑按钮*/
        private void MEdit_Click(object sender, EventArgs e)
        {
            PNo.Text = InputGradeDGV.SelectedRows[0].Cells[0].Value.ToString().Trim();
            PlayerNo = InputGradeDGV.SelectedRows[0].Cells[0].Value.ToString().Trim();//获取待修改学号。用于更新

            SName.Text = InputGradeDGV.SelectedRows[0].Cells[1].Value.ToString().Trim();
            SNoBox.Text = InputGradeDGV.SelectedRows[0].Cells[2].Value.ToString().Trim();
            GameNo = InputGradeDGV.SelectedRows[0].Cells[2].Value.ToString().Trim();//获取待修改项目编号，用于更新

            GameName.Text = InputGradeDGV.SelectedRows[0].Cells[3].Value.ToString().Trim();
            ResultBox.Text = InputGradeDGV.SelectedRows[0].Cells[4].Value.ToString().Trim();
            RankBox.Text = InputGradeDGV.SelectedRows[0].Cells[5].Value.ToString().Trim();
        }

        /*更新并保存*/
        private void MUpdate_Click(object sender, EventArgs e)
        {
            if (PNo.Text == "" || SName.Text == "" || SNoBox.Text == "" || GameName.Text == "" || ResultBox.Text == "" || RankBox.Text == "")
            {
                MessageBox.Show("信息缺失！请检查无误后更新信息");
            }
            else
            {
                try
                {

                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }

                    string prizeState = "无奖品";
                    if (Convert.ToInt32(RankBox.Text.Trim()) <= 3)
                    {
                        prizeState = "奖品待发放";
                    }
                    // string sql = " update GamesInfo  set  SNo ='" + SNo.Text + "', GameName='" + GameName.Text + "',GameTime='" + GameTime.Text + "',GameAddress='" + GameAddress.Text + "' where SNo = '" + key + "' ";
                    string sql = "update  players_sports_rel set PNo = @PNo,SNo = @SNoBox ,Result = @ResultBox,Rank =@Rank,Prize= @prizeState  " +
                                      "from (select players_sports_rel.PNo, PlayerInfo.PName,players_sports_rel.SNo,GamesInfo.GameName,\r\n               " +
                                      "players_sports_rel.Result,players_sports_rel.Rank from players_sports_rel\r\n             " +
                                      " left join PlayerInfo on players_sports_rel.PNo = PlayerInfo.PNo\r\n         " +
                                      " left join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo ) AS u " +
                                      "where players_sports_rel.PNo = @PlayerNo and players_sports_rel.SNo = @GameNo  ";


                    SqlCommand updateStyle = new SqlCommand(sql, conn);
                    updateStyle.Parameters.Add(new SqlParameter("@PNo", PNo.Text));
                    updateStyle.Parameters.Add(new SqlParameter("@SNoBox", SNoBox.Text));
                    updateStyle.Parameters.Add(new SqlParameter("@ResultBox", ResultBox.Text));
                    updateStyle.Parameters.Add(new SqlParameter("@Rank", RankBox.Text));
                    updateStyle.Parameters.Add(new SqlParameter("@prizeState", prizeState));
                    updateStyle.Parameters.Add(new SqlParameter("@PlayerNo", PlayerNo));
                    updateStyle.Parameters.Add(new SqlParameter("@GameNo", GameNo));
                    updateStyle.ExecuteNonQuery();
                    MessageBox.Show("项目信息更新成功！");
                    conn.Close();
                    populate();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }




        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (DePNo == "" || DeSNo=="")
            {
                MessageBox.Show("请选中一条待删除信息再进行删除！");
            }
            else
            {
                try
                {
                    
                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }

                    string sql = "delete from players_sports_rel where SNo = " + DeSNo + " and PNo = '"+DePNo+"'  ";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    System.Diagnostics.Debug.WriteLine("sql-->" + sql);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("成绩信息删除成功");
                    conn.Close();
                    populate();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        string DePNo = "";//点击DGV行后，获取待删除PNo
        string DeSNo = "";//点击DGV行后，获取待删除SNo
        private void InputGradeDGV_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DePNo = InputGradeDGV.SelectedRows[0].Cells[0].Value.ToString().Trim();//点击获取用户唯一No(学号)  
            DeSNo = InputGradeDGV.SelectedRows[0].Cells[2].Value.ToString().Trim();//点击获取用户唯一No(学号)  

        }

        private void InputGradeDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {
            PlayersManage playersManage = new PlayersManage();
            playersManage.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            GamesManage gamesManage = new GamesManage();
            gamesManage.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            UpdateManagerPwd updatePlayersPwd = new UpdateManagerPwd();
            updatePlayersPwd.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            SentPrize sentPrize = new SentPrize();
            sentPrize.Show();
            this.Hide();
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;
        private void IG_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
    }
}
