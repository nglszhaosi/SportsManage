﻿namespace SportManagerProject.Player
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.RegisterSex = new System.Windows.Forms.ComboBox();
            this.UPSex = new System.Windows.Forms.Label();
            this.UPSave = new System.Windows.Forms.Button();
            this.RegisterNo = new System.Windows.Forms.TextBox();
            this.RegisterClass = new System.Windows.Forms.TextBox();
            this.RegisterName = new System.Windows.Forms.TextBox();
            this.UPNo = new System.Windows.Forms.Label();
            this.UPcalss = new System.Windows.Forms.Label();
            this.UPName = new System.Windows.Forms.Label();
            this.RegisterPassword = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.RegisterUserName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.RegisterNum = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("华文行楷", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.ForeColor = System.Drawing.Color.Tomato;
            this.label5.Location = new System.Drawing.Point(67, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(420, 25);
            this.label5.TabIndex = 2;
            this.label5.Text = "欢迎使用传奇运动会管理系统注册功能";
            // 
            // RegisterSex
            // 
            this.RegisterSex.Font = new System.Drawing.Font("宋体", 12F);
            this.RegisterSex.FormattingEnabled = true;
            this.RegisterSex.Items.AddRange(new object[] {
            "男",
            "女"});
            this.RegisterSex.Location = new System.Drawing.Point(232, 268);
            this.RegisterSex.Name = "RegisterSex";
            this.RegisterSex.Size = new System.Drawing.Size(164, 24);
            this.RegisterSex.TabIndex = 3;
            this.RegisterSex.Text = "(性别)";
            // 
            // UPSex
            // 
            this.UPSex.AutoSize = true;
            this.UPSex.Font = new System.Drawing.Font("宋体", 12F);
            this.UPSex.Location = new System.Drawing.Point(150, 267);
            this.UPSex.Name = "UPSex";
            this.UPSex.Size = new System.Drawing.Size(39, 16);
            this.UPSex.TabIndex = 31;
            this.UPSex.Text = "性别";
            // 
            // UPSave
            // 
            this.UPSave.ForeColor = System.Drawing.Color.LimeGreen;
            this.UPSave.Location = new System.Drawing.Point(241, 500);
            this.UPSave.Name = "UPSave";
            this.UPSave.Size = new System.Drawing.Size(76, 35);
            this.UPSave.TabIndex = 7;
            this.UPSave.Text = "注册";
            this.UPSave.UseVisualStyleBackColor = true;
            this.UPSave.Click += new System.EventHandler(this.UPSave_Click);
            // 
            // RegisterNo
            // 
            this.RegisterNo.Location = new System.Drawing.Point(232, 373);
            this.RegisterNo.Multiline = true;
            this.RegisterNo.Name = "RegisterNo";
            this.RegisterNo.Size = new System.Drawing.Size(164, 34);
            this.RegisterNo.TabIndex = 5;
            // 
            // RegisterClass
            // 
            this.RegisterClass.Location = new System.Drawing.Point(232, 320);
            this.RegisterClass.Multiline = true;
            this.RegisterClass.Name = "RegisterClass";
            this.RegisterClass.Size = new System.Drawing.Size(164, 34);
            this.RegisterClass.TabIndex = 4;
            // 
            // RegisterName
            // 
            this.RegisterName.Location = new System.Drawing.Point(232, 206);
            this.RegisterName.Multiline = true;
            this.RegisterName.Name = "RegisterName";
            this.RegisterName.Size = new System.Drawing.Size(164, 34);
            this.RegisterName.TabIndex = 2;
            // 
            // UPNo
            // 
            this.UPNo.AutoSize = true;
            this.UPNo.Font = new System.Drawing.Font("宋体", 12F);
            this.UPNo.Location = new System.Drawing.Point(152, 382);
            this.UPNo.Name = "UPNo";
            this.UPNo.Size = new System.Drawing.Size(39, 16);
            this.UPNo.TabIndex = 26;
            this.UPNo.Text = "学号";
            // 
            // UPcalss
            // 
            this.UPcalss.AutoSize = true;
            this.UPcalss.Font = new System.Drawing.Font("宋体", 12F);
            this.UPcalss.Location = new System.Drawing.Point(140, 329);
            this.UPcalss.Name = "UPcalss";
            this.UPcalss.Size = new System.Drawing.Size(71, 16);
            this.UPcalss.TabIndex = 25;
            this.UPcalss.Text = "专业班级";
            // 
            // UPName
            // 
            this.UPName.AutoSize = true;
            this.UPName.Font = new System.Drawing.Font("宋体", 12F);
            this.UPName.Location = new System.Drawing.Point(152, 215);
            this.UPName.Name = "UPName";
            this.UPName.Size = new System.Drawing.Size(39, 16);
            this.UPName.TabIndex = 24;
            this.UPName.Text = "姓名";
            // 
            // RegisterPassword
            // 
            this.RegisterPassword.Location = new System.Drawing.Point(232, 143);
            this.RegisterPassword.Multiline = true;
            this.RegisterPassword.Name = "RegisterPassword";
            this.RegisterPassword.Size = new System.Drawing.Size(164, 34);
            this.RegisterPassword.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 12F);
            this.label1.Location = new System.Drawing.Point(152, 152);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 16);
            this.label1.TabIndex = 33;
            this.label1.Text = "密码";
            // 
            // RegisterUserName
            // 
            this.RegisterUserName.Location = new System.Drawing.Point(232, 79);
            this.RegisterUserName.Multiline = true;
            this.RegisterUserName.Name = "RegisterUserName";
            this.RegisterUserName.Size = new System.Drawing.Size(164, 34);
            this.RegisterUserName.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 12F);
            this.label2.Location = new System.Drawing.Point(152, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 16);
            this.label2.TabIndex = 35;
            this.label2.Text = "账号";
            // 
            // RegisterNum
            // 
            this.RegisterNum.Location = new System.Drawing.Point(232, 438);
            this.RegisterNum.Multiline = true;
            this.RegisterNum.Name = "RegisterNum";
            this.RegisterNum.Size = new System.Drawing.Size(164, 34);
            this.RegisterNum.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 12F);
            this.label3.Location = new System.Drawing.Point(131, 452);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 16);
            this.label3.TabIndex = 37;
            this.label3.Text = "运动会编号";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 12F);
            this.label4.Location = new System.Drawing.Point(528, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(15, 16);
            this.label4.TabIndex = 39;
            this.label4.Text = "X";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("宋体", 12F);
            this.label7.Location = new System.Drawing.Point(493, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(15, 16);
            this.label7.TabIndex = 40;
            this.label7.Text = "-";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            this.label7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Reg_MouseDown);
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(544, 563);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.RegisterNum);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.RegisterUserName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.RegisterPassword);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.RegisterSex);
            this.Controls.Add(this.UPSex);
            this.Controls.Add(this.UPSave);
            this.Controls.Add(this.RegisterNo);
            this.Controls.Add(this.RegisterClass);
            this.Controls.Add(this.RegisterName);
            this.Controls.Add(this.UPNo);
            this.Controls.Add(this.UPcalss);
            this.Controls.Add(this.UPName);
            this.Controls.Add(this.label5);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Register";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Register";
            this.Load += new System.EventHandler(this.Register_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Reg_MouseDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox RegisterSex;
        private System.Windows.Forms.Label UPSex;
        private System.Windows.Forms.Button UPSave;
        private System.Windows.Forms.TextBox RegisterNo;
        private System.Windows.Forms.TextBox RegisterClass;
        private System.Windows.Forms.TextBox RegisterName;
        private System.Windows.Forms.Label UPNo;
        private System.Windows.Forms.Label UPcalss;
        private System.Windows.Forms.Label UPName;
        private System.Windows.Forms.TextBox RegisterPassword;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox RegisterUserName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox RegisterNum;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
    }
}