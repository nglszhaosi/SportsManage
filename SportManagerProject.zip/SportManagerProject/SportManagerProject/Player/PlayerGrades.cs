﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportManagerProject.Player
{
    public partial class PlayerGrades : Form
    {
        public PlayerGrades()
        {
            InitializeComponent();
            populate();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Playerq playerq = new Playerq();
            playerq.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            PlayerGamesinfo playergamesinfo = new PlayerGamesinfo();    
            playergamesinfo.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            UpdatePlayerInfo updatePlayerInfo = new UpdatePlayerInfo();
            updatePlayerInfo.Show();
            this.Hide();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\lenove\Documents\SportManagerDB.mdf;Integrated Security=True;Connect Timeout=30");

        public void populate()
        {
            try
            {
                conn.Open();
                //string sql = "select * from PlayerGrades";
                string sql = "select  PlayerInfo.PNo,PlayerInfo.PName,GamesInfo.SNo,GamesInfo.GameName,players_sports_rel.Result,players_sports_rel.Rank,players_sports_rel.Prize from players_sports_rel " +
                    " \r\nleft join PlayerInfo on players_sports_rel.PNo = PlayerInfo.PNo" +
                    "\r\nleft join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo  where players_sports_rel.PNo = '" + GlobalData.No + "' ";
                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(adapter);
                var ds = new DataSet();
                adapter.Fill(ds);
                GradesDGV.DataSource = ds.Tables[0];
                conn.Close();
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private void GameDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;
        private void PG_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }

        private void label7_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
