﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;
using System.Runtime.InteropServices;

namespace SportManagerProject.Player
{
    public partial class UpdatePlayerInfo : Form
    {
        public UpdatePlayerInfo()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\lenove\Documents\SportManagerDB.mdf;Integrated Security=True;Connect Timeout=30");
        private void UPSave_Click(object sender, EventArgs e)
        {
            if (UPNameContent.Text == "" || UPClassContent.Text == "" || UPSexContent.Text == "" || UPNoContent.Text ==  ""|| UPSexContent.SelectedIndex == -1)
            {
                MessageBox.Show("信息缺失！！！");
            }
            else
            {
                try {
                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }
                    string sql = "update  PlayerInfo set  PNo = '" + UPNoContent.Text + "',PName='" + UPNameContent.Text + "',PSex='" + UPSexContent.SelectedItem.ToString() + "',Pclass='" + UPClassContent.Text + "' where PNo = '" + GlobalData.No + "';";
                       
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("个人信息修改成功！");
                GlobalData.PNo = UPNoContent.Text;
                conn.Close(); 
            }
            catch(Exception ex) {
                MessageBox.Show(ex.Message);
            }
            }
        }

        private void label10_Click(object sender, EventArgs e)
        {
            PlayerGrades playerGrades = new PlayerGrades();
            playerGrades.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            PlayerGamesinfo playerGamesinfo = new PlayerGamesinfo();
            playerGamesinfo.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Playerq playerq = new Playerq();
            playerq.Show();
            this.Hide();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void UpdatePlayerInfo_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;

        private void UPI_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
    }
}
