﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportManagerProject.Player
{
    public partial class PlayerGamesinfo : Form
    {
        public PlayerGamesinfo()
        {
            InitializeComponent();
            populate();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\lenove\Documents\SportManagerDB.mdf;Integrated Security=True;Connect Timeout=30");

        public void populate()
        {
            try
            {

                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                //string sql = "select GamesInfo.GameName,GamesInfo.GameAddress,GamesInfo.GameTime from players_sports_rel  left join PlayerInfo on players_sports_rel.PNo =  '" + GlobalData.No + "' left join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo";
                string sql = "select GamesInfo.SNo,GamesInfo.GameName,GamesInfo.GameAddress,GamesInfo.GameTime" +
                    " \tfrom players_sports_rel  left join PlayerInfo on players_sports_rel.PNo = PlayerInfo.PNo" +
                    "\tleft join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo  where players_sports_rel.PNo = '" + GlobalData.No + "'  ";
                System.Diagnostics.Debug.WriteLine("sql-->" + sql);
                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(adapter);
                var ds = new DataSet();
                adapter.Fill(ds);
                GameDGV.DataSource = ds.Tables[0];
                conn.Close();
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            Playerq playerq = new Playerq();
            playerq.Show();
            this.Hide();
        }

        private void label9_Click_1(object sender, EventArgs e)
        {
            PlayerGrades playergrades = new PlayerGrades();
            playergrades.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            UpdatePlayerInfo updatePlayerInfo = new UpdatePlayerInfo();
            updatePlayerInfo.Show();
            this.Hide();
        }

        private void PlayerGamesinfo_Load(object sender, EventArgs e)
        {
         
        }
        private void GameDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            GlobalData.SNo = GameDGV.SelectedRows[0].Cells[0].Value.ToString().Trim();
            
        }



        private void UPSave_Click(object sender, EventArgs e)
        {
            GameSign gameSign = new GameSign();
            gameSign.Show();

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }



      
        private void button2_Click(object sender, EventArgs e)
        {

            populate();
                
         }

        /*
     取消报名
     */
        private void button1_Click(object sender, EventArgs e)
        {
            if (GlobalData.SNo == null)
            {
                MessageBox.Show("请至少选中一个项目！");
            }
            else
            {
                try
                {

                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }

                    //项目取消报名
                    string sql = "delete from  players_sports_rel where PNo = '" + GlobalData.No + "' and  SNo = '" + GlobalData.SNo + "' ";
                    System.Diagnostics.Debug.WriteLine("sql-->" + sql);

                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("项目取消成功！");

                    //取消报名后剩余数量加一
                    int amount = 0;
                    string sql2 = "select amount from GamesInfo where SNo = '" + GlobalData.SNo + "' ";
                    SqlCommand cmd2 = new SqlCommand(sql2, conn);
                    SqlDataReader reader = cmd2.ExecuteReader();
                    if (reader.Read())
                    {
                        amount = Convert.ToInt32(reader["amount"].ToString().Trim());
                    }
                    reader.Close();
                    amount += 1;
                    string sql3 = "update GamesInfo set amount = " + amount + " where SNo = '" + GlobalData.SNo + "' ";
                    SqlCommand cmd3 = new SqlCommand(sql3, conn);//取消报名成功后执行项目数量加一
                    cmd3.ExecuteNonQuery();


                    conn.Close();
                    populate();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

  

        private void GameDGV_CellContentClick_2(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;

        private void PGI_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
    }
    
}
