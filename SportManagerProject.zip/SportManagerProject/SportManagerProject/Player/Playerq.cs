﻿using SportManagerProject.Player;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace SportManagerProject
{
    public partial class Playerq : Form
    {
        public Playerq()
        {
            InitializeComponent();
            populate();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\lenove\Documents\SportManagerDB.mdf;Integrated Security=True;Connect Timeout=30");
        public void populate() {

            try
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                string sql = "select * from PlayerInfo where PNo = '"+GlobalData.PNo+"' ";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    GlobalData.UserName = reader["PName"].ToString();
                    GlobalData.Sex = reader["PSex"].ToString();
                    GlobalData.Class = reader["PClass"].ToString();
                    GlobalData.No = reader["PNo"].ToString();
                    GlobalData.Num = reader["PNum"].ToString();

                }
                reader.Close();
                conn.Close();
            }
            catch(Exception ex) {
                MessageBox.Show(ex.Message);
            }

        }
        private void Playerq_Load(object sender, EventArgs e)
        {
            PlayerName.Text = GlobalData.UserName;
            PlayerRealName.Text = GlobalData.UserName;
            Sex.Text = GlobalData.Sex;
            Class.Text = GlobalData.Class;
            No.Text = GlobalData.No;
            Num.Text = GlobalData.Num;
        }

        private void label8_Click(object sender, EventArgs e)
        {
            PlayerGamesinfo playerGamesinfo = new PlayerGamesinfo();
            playerGamesinfo.Show();
            this.Hide();
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {
          
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {
         
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void label9_Click(object sender, EventArgs e)
        {
            PlayerGrades playerGrades = new PlayerGrades();
            playerGrades.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            UpdatePlayerInfo updatePlayerInfo = new UpdatePlayerInfo();
            updatePlayerInfo.Show();
            this.Hide();
        }

        private void PlayerRealName_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;


        private void label7_Click_1(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Player_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
    }
}
