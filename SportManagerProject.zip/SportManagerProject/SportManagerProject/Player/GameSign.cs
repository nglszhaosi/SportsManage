﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace SportManagerProject.Player
{
    public partial class GameSign : Form
    {
        public GameSign()
        {
            InitializeComponent();
            populate();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\lenove\Documents\SportManagerDB.mdf;Integrated Security=True;Connect Timeout=30");

        /*
         刷新信息
         */
        public void populate()
        {
            try
            {
                if (conn.State == ConnectionState.Closed) {
                    conn.Open();
                }



                //string sql = "select GamesInfo.GameName,GamesInfo.GameAddress,GamesInfo.GameTime from players_sports_rel  left join PlayerInfo on players_sports_rel.PNo =  '" + GlobalData.No + "' left join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo";
                int sexNum = 0;
                System.Diagnostics.Debug.WriteLine("GlobalData.Sex-->" + GlobalData.Sex);
                string sex = "男";
                if (GlobalData.Sex.Trim()==sex)
                {
                    sexNum = 1;
                }
                string sql = "select SNo,GameName,GameTime,GameAddress,amount from GamesInfo  where GameSex = "+sexNum+" ";
                System.Diagnostics.Debug.WriteLine("sql-->" + sql);
                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(adapter);
                var ds = new DataSet();
                adapter.Fill(ds);
                GameSIgnDGV.DataSource = ds.Tables[0];



                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        int amount = 0;//临时获取剩余项目数量
        private void GameDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            GlobalData.SNo = GameSIgnDGV.SelectedRows[0].Cells[0].Value.ToString().Trim();//临时获取报名项目编号
            amount = Convert.ToInt32(GameSIgnDGV.SelectedRows[0].Cells[4].Value.ToString().Trim());
        }

        private void label11_Click(object sender, EventArgs e)
        {
         
            this.Close();
          
        }

        /*
         报名
         */
        private void UPSave_Click(object sender, EventArgs e)
        {
            try
            {

                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                System.Diagnostics.Debug.WriteLine("11111111111");

                //获取选中项目时间
                string sql2 = "select GamesInfo.GameTime from GamesInfo where SNo = '" + GlobalData.SNo + "' ";
                SqlCommand cmd2 = new SqlCommand(sql2, conn);
                SqlDataReader reader2 = cmd2.ExecuteReader();
                string datetime = "";
                if (reader2.Read())
                {
                    datetime = reader2["GameTime"].ToString();
                }
                System.Diagnostics.Debug.WriteLine("2222");
                reader2.Close();
                System.Diagnostics.Debug.WriteLine("3333");
                //判断选中项目是否与已有项目时间冲突
                string sql3 = "select GamesInfo.GameTime" +   //获取该运动员已报名项目的时间
                    " \tfrom players_sports_rel  left join PlayerInfo on players_sports_rel.PNo = PlayerInfo.PNo" +
                    "\tleft join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo  where players_sports_rel.PNo = '" + GlobalData.No + "' ";

                Boolean flag = true;//标识是否有相同时间，true为无
                // 建立命令对象sql是SQL语句，conn为连接变量
                System.Diagnostics.Debug.WriteLine("4444");
                SqlCommand cmd3 = new SqlCommand(sql3, conn);
                //执行命令对象获得读取器
                SqlDataReader reader = cmd3.ExecuteReader();
                //判断读取器中是否有内容，即是已有顾客使用的用户名
                System.Diagnostics.Debug.WriteLine("555");
                if (reader.Read())
                {
                    System.Diagnostics.Debug.WriteLine("666");
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        if (datetime.Equals(reader[i].ToString()))
                        {
                            System.Diagnostics.Debug.WriteLine("reader[i].ToString()-->" + reader[i].ToString());
                            System.Diagnostics.Debug.WriteLine("datetime-->" + datetime);

                            flag = false;
                            break;
                        }

                    }
                }
                System.Diagnostics.Debug.WriteLine("777");
                reader.Close();

                //判断选中项目是否报名
                SqlDataAdapter sda = new SqlDataAdapter("select count(*) from players_sports_rel where PNo =  '" + GlobalData.No + "' and SNo = '" + GlobalData.SNo + "' ", conn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                System.Diagnostics.Debug.WriteLine("888");
                if (dt.Rows[0][0].ToString() == "1")//判断选中项目是否报名
                {
                    MessageBox.Show("该项目已报名！！请勿重复报名");
                }
                else if (!flag)
                {
                    MessageBox.Show("选中项目与已报名项目时间冲突！请选择其它项目");
                }
                else
                {


                    //string sql = "select GamesInfo.GameName,GamesInfo.GameAddress,GamesInfo.GameTime from players_sports_rel  left join PlayerInfo on players_sports_rel.PNo =  '" + GlobalData.No + "' left join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo";
                    string sql = "insert into players_sports_rel(PNo,SNo) values('" + GlobalData.No + "','" + GlobalData.SNo + "')";
                    System.Diagnostics.Debug.WriteLine("sql-->" + sql);

                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("项目报名成功！");
                    if (amount == 0)
                    {
                        MessageBox.Show("项目数量为0！请选择其它项目报名");
                    }
                    else
                    {
                        amount -= 1;//项目剩余数量减一
                        string sql4 = "update GamesInfo set amount = " + amount + " where SNo = '" + GlobalData.SNo + "' ";
                        SqlCommand cmd4 = new SqlCommand(sql4, conn);//报名成功后执行项目数量减一
                        cmd4.ExecuteNonQuery();
                    }

                    populate();
                    conn.Close();

                }




            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;


        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void GS_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
    }
}
