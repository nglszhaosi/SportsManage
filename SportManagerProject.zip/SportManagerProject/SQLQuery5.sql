﻿update players_sports_rel set Prize = 'abc'  where PNo = '20200202468' and SNo = '1003' and  Rank >3 ;
 update players_sports_rel set   Prize ='cdf'  where PNo = '20200202468' and SNo = '1003' and  Rank <=3 ;


     update  players_sports_rel set PNo = '20200202468',SNo = '1003' ,Result = '13:5',Rank = '11'  from (select players_sports_rel.PNo, PlayerInfo.PName,players_sports_rel.SNo,GamesInfo.GameName,
               players_sports_rel.Result,players_sports_rel.Rank from players_sports_rel
              left join PlayerInfo on players_sports_rel.PNo = PlayerInfo.PNo
          left join GamesInfo  on players_sports_rel.SNo = GamesInfo.SNo ) AS u where players_sports_rel.PNo = '20200202468' and players_sports_rel.SNo = '1003';
         
insert into players_sports_rel(Prize)  values('无奖品')  where `Rank` ='3'
          


          